#include "osbcli.cpp"
using namespace std;

int main(){
  printf("\nWelcome to OpenSystemBench\n");
  OSBBenchmarkConfig osb;
  osb.show_main_menu();
  return 0;
}

